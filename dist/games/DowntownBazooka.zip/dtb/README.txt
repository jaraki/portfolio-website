https://www.microsoft.com/en-us/download/details.aspx?id=48145

install the x86 redis package here if have any problems